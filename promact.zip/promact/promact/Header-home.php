<?php
/**
 * The Header template for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
    <!--<![endif]-->
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width">
        <title><?php wp_title('|', true, 'right'); ?></title>
        <link rel="profile" href="http://gmpg.org/xfn/11">
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
        <!--[if lt IE 9]>
        <script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
        <![endif]-->
        <?php wp_head(); ?>
    </head>

    <body <?php body_class(); ?>>
        <div><!--Main green Title Block-->
            <div class="row main-block" style="background-image: url('http://www.space.ca/wp-content/uploads/2015/05/game-of-thrones-poster_85627-1920x1200.jpg');background-size: cover;">
                <div class="col-md-12 text-center bg-cover" style="background:rgba(0,0,0,0.4) !important;">
                    <img class="logo" alt="logo" src="<?php echo get_theme_root_uri()?>/twentyseventeen/assets/images/logo.png">

                    <h1 class="olympics-title">PROMACT OLYMPICS</h1>
                    <h2 class="olympics-date">2017</h2>
                    <h2 class="battle-start">Battle has begun.!! Enjoy !!</h2>
                    <img class="angle-down" src="<?php echo get_theme_root_uri()?>/twentyseventeen/assets/images/angle-icon-down.png">
                </div>
            </div>

<!--                <div id="navbar" class="navbar">
                    <div class="row">
                        <nav id="site-navigation" class="navigation main-navigation navbar-default" role="navigation">
                            <?php //wp_nav_menu(array('theme_location' => 'primary', 'menu_class' => 'nav-menu')); ?>
                        </nav>
                    </div>
                </div>-->
            </header>

            <div id="main" class="site-main">                

<script type="text/javascript" src="<?php echo get_template_directory_uri() . '/js/bootstrap.min.js'; ?>"></script>

<script type="text/javascript">
/*    var num=603;
    $(window).bind('scroll', function() {           
    //alert("function called");
    if ($(window).scrollTop() >num) {
        $('.nav-menu').addClass('fixed');
    } else {
        $('.nav-menu').removeClass('fixed');
    }
});
*/
</script>